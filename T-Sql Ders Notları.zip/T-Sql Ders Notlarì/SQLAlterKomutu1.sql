-- Alter Komutu 
alter table Kitaplar2 add SayfaSayisi smallint 

-- s�tunun veritipini de�i�tirmek i�in 
alter table Kitaplar2 alter column SayfaSayisi int
