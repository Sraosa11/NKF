  -- 2) SUM : Tabloda belirtilen s�tunlardaki de�erlerin toplam�n� g�sterir .
  select * from Urunler
-- T�m �r�nlerimizin toplam stok miktar� 
select SUM(HedefStokDuzeyi) from Urunler

-- Stoklar�m�zda bulunan t�m �r�nlerin toplam de�eri 
select BirimFiyati * HedefStokDuzeyi from Urunler -- de�erleri sadece �arpar

select SUM(BirimFiyati * HedefStokDuzeyi) from Urunler	-- de�erleri �arpar ve birbiriyle toplar

-- �imdiye kadar yap�lan sat��lardan kazan�lan toplam miktar 
select * from [Satis Detaylari]

select SUM ( BirimFiyati * Miktar * (1 - �ndirim)) from [Satis Detaylari]

-- 2 idli �r�n�n sat���ndan elde edilen toplam tutar 
select * from [Satis Detaylari] where UrunID = 2
select sum(BirimFiyati * Miktar * (1 - �ndirim)) from [Satis Detaylari] where UrunID = 2

-- 1996 y�l�nda �denen toplam nakliye �creti 
select sum(NakliyeUcreti) from Satislar where SevkTarihi > '1995 - 12 - 31' and SevkTarihi < '1997 - 01 - 01'