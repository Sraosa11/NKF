-- tekrar etmeyen 
select ad , soyad from Tbl_Ogrenci
union 
select ad , soyad from ogrenci2

-- tekrar eden - etmeyen 
select ad , soyad from Tbl_Ogrenci
union all
select ad , soyad from ogrenci2

-- kesi�en veriler ial�r
select ad , soyad from Tbl_Ogrenci
intersect  
select ad , soyad from ogrenci2

-- fark� g�steriyor 
select ad , soyad from Tbl_Ogrenci
except 
select ad , soyad from ogrenci2