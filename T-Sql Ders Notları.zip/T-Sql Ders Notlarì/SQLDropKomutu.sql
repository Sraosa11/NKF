-- Kitaplar2 tablosunu silmek i�in ; 
drop table Kitaplar2 

-- Kitaplar tablosunda sayfasay�s�n� silmek i�in ; 
alter table Kitaplar drop column Sayfa