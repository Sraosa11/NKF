	-- 3) AVG : Ortalama Hesap 

-- Kategori ID'si 3 olan �r�nlerin ortalama birim fiyat� 
select AVG(BirimFiyati) from Urunler where KategoriID = 3 

-- Nakliyeci ID'si 2 olan nakliyeciye �denen ortalama nakliye �creti 
select AVG(NakliyeUcreti) from Satislar where ShipVia = 2 

